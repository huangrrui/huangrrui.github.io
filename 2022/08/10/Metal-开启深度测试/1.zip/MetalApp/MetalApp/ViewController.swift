//
//  ViewController.swift
//  MetalApp
//
//  Created by 黄瑞 on 2022/7/29.
//

import Cocoa
import MetalKit

struct Vertex {
    var position: vector_float3
    var color: vector_float3
}

struct VertexTexture {
    var position: vector_float2
    var coord: vector_float2
}

class ViewController: NSViewController {
    @IBOutlet weak var mtkView: MTKView!
    
    var device: MTLDevice!
    var commandQueue: MTLCommandQueue!
    
    var trianglePipeline: MTLRenderPipelineState!
    var depth: MTLDepthStencilState!
    
    var texturePipeline: MTLRenderPipelineState!
    var originTexture: MTLTexture!
    var targetTexture: MTLTexture!
    var targetRenderPass: MTLRenderPassDescriptor!
    var cgImage: CGImage!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        device = MTLCreateSystemDefaultDevice()!
        commandQueue = device.makeCommandQueue()!
        
        configMTKView()
        
        configTrianglePipeline()
        configDepth()
        
//        configTexture()
//        configTexturePipeline()
//        configTargetRenderPass()
        
//        drawTexture()
    }
    
    func configMTKView() -> Void {
        mtkView.device = device
        mtkView.delegate = self
        mtkView.enableSetNeedsDisplay = true
        mtkView.clearColor = MTLClearColorMake(0.1,0,0,1)
        mtkView.depthStencilPixelFormat = .depth32Float
    }
    
    func configTrianglePipeline() -> Void {
        let library = device.makeDefaultLibrary()!
        let vertexShader = library.makeFunction(name: "vertexShader")!
        let fragmentShader = library.makeFunction(name: "fragmentShader")!
        
        let descriptor = MTLRenderPipelineDescriptor()
        descriptor.vertexFunction = vertexShader
        descriptor.fragmentFunction = fragmentShader
        descriptor.colorAttachments[0].pixelFormat = mtkView.colorPixelFormat
        descriptor.depthAttachmentPixelFormat = mtkView.depthStencilPixelFormat
        trianglePipeline = try! device.makeRenderPipelineState(descriptor: descriptor)
    }
    
    func configDepth() -> Void {
        let descriptor = MTLDepthStencilDescriptor()
        descriptor.depthCompareFunction = .lessEqual
        descriptor.isDepthWriteEnabled = true
        depth = device.makeDepthStencilState(descriptor: descriptor)!
    }
    
    func configTexture() -> Void {
        let path = Bundle.main.path(forResource: "2", ofType: "jpg")!
        let data = try! Data(contentsOf: URL(fileURLWithPath: path))
        let image = NSImage(data: data)!
        cgImage = image.cgImage(forProposedRect: nil, context: nil, hints: nil)!
        let imageData = cgImage.dataProvider!.data! as NSData
        
        var descriptor = MTLTextureDescriptor()
        descriptor.textureType = .type2D
        descriptor.pixelFormat = .rgba8Unorm
        descriptor.width = cgImage.width
        descriptor.height = cgImage.height
        descriptor.usage = [.shaderRead]
        originTexture = device.makeTexture(descriptor: descriptor)!
        
        let region = MTLRegionMake2D(0, 0, cgImage.width, cgImage.height)
        originTexture.replace(region: region, mipmapLevel: 0, withBytes: imageData.bytes, bytesPerRow: cgImage.bytesPerRow)
        
        descriptor = MTLTextureDescriptor()
        descriptor.textureType = .type2D
        descriptor.pixelFormat = .rgba8Unorm
        descriptor.width = cgImage.width
        descriptor.height = cgImage.height
        descriptor.usage = [.renderTarget]
        targetTexture = device.makeTexture(descriptor: descriptor)!
    }
    
    func configTexturePipeline() -> Void {
        let library = device.makeDefaultLibrary()!
        let vertexShader = library.makeFunction(name: "vertexShaderTexture")!
        let fragmentShader = library.makeFunction(name: "fragmentShaderTexture")!

        let descriptor = MTLRenderPipelineDescriptor()
        descriptor.vertexFunction = vertexShader
        descriptor.fragmentFunction = fragmentShader
        descriptor.colorAttachments[0].pixelFormat = targetTexture.pixelFormat
        texturePipeline = try! device.makeRenderPipelineState(descriptor: descriptor)
    }
    
    func configTargetRenderPass() -> Void {
        let descriptor = MTLRenderPassDescriptor()
        descriptor.colorAttachments[0].loadAction = .load
        descriptor.colorAttachments[0].clearColor = MTLClearColorMake(0.1, 0, 0, 1)
        descriptor.colorAttachments[0].storeAction = .store
        descriptor.colorAttachments[0].texture = targetTexture
        targetRenderPass = descriptor
    }
    
    func drawTriangle() -> Void {
        let commandBuffer = commandQueue.makeCommandBuffer()!
        let commandEncoder = commandBuffer.makeRenderCommandEncoder(descriptor: mtkView.currentRenderPassDescriptor!)!
        
        let vertices = [
            Vertex(position: vector_float3(-0.75,   0, 0.25), color: vector_float3(1, 0, 0)),
            Vertex(position: vector_float3( 0.25,   0, 0.25), color: vector_float3(0, 1, 0)),
            Vertex(position: vector_float3( -0.5, 0.5, 0.25), color: vector_float3(0, 0, 1)),
            
            Vertex(position: vector_float3( 0.75,   0, 0.75), color: vector_float3(1, 0, 0)),
            Vertex(position: vector_float3(-0.25,   0, 0.75), color: vector_float3(0, 1, 0)),
            Vertex(position: vector_float3(  0.5, 0.5, 0.75), color: vector_float3(0, 0, 1)),
        ]
        
        commandEncoder.setRenderPipelineState(trianglePipeline)
        commandEncoder.setDepthStencilState(depth)
        commandEncoder.setVertexBytes(vertices, length: MemoryLayout<Vertex>.size * 6, index: 0)
        commandEncoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 6)
        commandEncoder.endEncoding()
        
        commandBuffer.present(mtkView.currentDrawable!)
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()
        
    }
    
    func drawTexture() -> Void {
        let commandBuffer = commandQueue.makeCommandBuffer()!
        let commandEncoder = commandBuffer.makeRenderCommandEncoder(descriptor: targetRenderPass)!
        
        let vertices = [
            VertexTexture(position: vector_float2(-1, 1), coord: vector_float2(0, 0)),
            VertexTexture(position: vector_float2(-1,-1), coord: vector_float2(0, 1)),
            VertexTexture(position: vector_float2( 1,-1), coord: vector_float2(1, 1)),
            
            VertexTexture(position: vector_float2(-1, 1), coord: vector_float2(0, 0)),
            VertexTexture(position: vector_float2( 1, 1), coord: vector_float2(1, 0)),
            VertexTexture(position: vector_float2( 1,-1), coord: vector_float2(1, 1)),
        ]
        
        commandEncoder.setRenderPipelineState(texturePipeline)
        commandEncoder.setVertexBytes(vertices, length: MemoryLayout<VertexTexture>.size * 6, index: 0)
        commandEncoder.setFragmentTexture(originTexture, index: 0)
        commandEncoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 6)
        commandEncoder.endEncoding()
                
        let bytesPerPixel = 4
        let bytesPerRow   = Int(cgImage.width) * bytesPerPixel;
        let bytesPerImage = Int(cgImage.height) * bytesPerRow;

        let buffer = device.makeBuffer(length: bytesPerImage, options: .storageModeShared)!
        
        let origin = MTLOriginMake(0, 0, 0)
        let size = MTLSizeMake(cgImage.width, cgImage.height, 1)
        let blitEncoder = commandBuffer.makeBlitCommandEncoder()!
        
        blitEncoder.copy(from: targetTexture, sourceSlice: 0, sourceLevel: 0, sourceOrigin: origin, sourceSize: size, to: buffer, destinationOffset: 0, destinationBytesPerRow: bytesPerRow, destinationBytesPerImage: bytesPerImage)
        blitEncoder.endEncoding()
        
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()
        
        /// pixel format 转换 bgra -> rgba
        for i in 0..<buffer.length / 4 {
            let b = buffer.contents().advanced(by: i*4+0).load(as: UInt8.self)
            let g = buffer.contents().advanced(by: i*4+1).load(as: UInt8.self)
            let r = buffer.contents().advanced(by: i*4+2).load(as: UInt8.self)
            let a = buffer.contents().advanced(by: i*4+3).load(as: UInt8.self)
            buffer.contents().advanced(by: i*4+0).storeBytes(of: r, as: UInt8.self)
            buffer.contents().advanced(by: i*4+1).storeBytes(of: g, as: UInt8.self)
            buffer.contents().advanced(by: i*4+2).storeBytes(of: b, as: UInt8.self)
            buffer.contents().advanced(by: i*4+3).storeBytes(of: a, as: UInt8.self)
        }
        
        let data = Data(bytes: buffer.contents(), count: buffer.length)
        let provider = CGDataProvider(data: data as CFData)!
        let cgImage = CGImage(width: size.width, height: size.height, bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: bytesPerRow, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: .byteOrder32Big, provider: provider, decode: nil, shouldInterpolate: false, intent: .defaultIntent)!
        let image = NSImage(cgImage: cgImage, size: NSSize(width: size.width, height: size.height))
        print(image)
        saveImage(image)

    }
    
    func readDepth(_ touchPoint: CGPoint) -> Void {
        let commandBuffer = commandQueue.makeCommandBuffer()!
        
        let blitEncoder = commandBuffer.makeBlitCommandEncoder()!
        let depthTexture = mtkView.depthStencilTexture!
        let buffer = device.makeBuffer(length: 4, options: .storageModeShared)!
        let origin = MTLOriginMake(Int(touchPoint.x), Int(touchPoint.y), 0)
        let size = MTLSizeMake(1, 1, 1)
        blitEncoder.copy(from: depthTexture, sourceSlice: 0, sourceLevel: 0, sourceOrigin: origin, sourceSize: size, to: buffer, destinationOffset: 0, destinationBytesPerRow: 4, destinationBytesPerImage: 4)
        blitEncoder.endEncoding()
        
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()

        let depth = buffer.contents().advanced(by: 0).load(as: Float32.self)
        print(depth)
    }
    
    override func mouseDown(with event: NSEvent) {
        print(#function)
    }
    override func mouseDragged(with event: NSEvent) {
        print(#function)
    }
    override func mouseUp(with event: NSEvent) {
        var point = mtkView.convertToBacking(event.locationInWindow)
        point.y = mtkView.drawableSize.height - point.y
        readDepth(point)
    }

    func saveImage(_ image: NSImage) -> Void {
        if let bits = image.representations.first as? NSBitmapImageRep {
            let data = bits.representation(using: .jpeg, properties: [:])! as NSData
            try! data.write(to: URL(fileURLWithPath: "/Users/huangrui/Desktop/1.jpg"))
        }
    }
}

extension ViewController: MTKViewDelegate {
    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
    }
    
    func draw(in view: MTKView) {
        drawTriangle()
    }
}
