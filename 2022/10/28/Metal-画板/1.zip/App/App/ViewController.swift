//
//  ViewController.swift
//  App
//
//  Created by 黄瑞 on 2022/9/9.
//

import UIKit
import MetalKit

private let kScreenWidth = UIScreen.main.bounds.size.width
private let kScreenHeight = UIScreen.main.bounds.size.height

class ViewController: UIViewController {
    var canvas: CanvasView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .gray
        
        guard let device = MTLCreateSystemDefaultDevice() else { return }
        
        let width = kScreenWidth
        let height = width
        let frame = CGRect.init(origin: .zero, size: .init(width: width, height: height))
        canvas = CanvasView(frame: frame, device: device)
        canvas.center = self.view.center
        view.addSubview(canvas)
        
        // 读取图片
        if true {
            let image = UIImage(named: "origin")!
            canvas.setOriginalImage(origin: image)
            let mask = UIImage(named: "mask")!
            canvas.setMaskImage(mask: mask)
        } else {
            let image = UIImage(named: "1")!
            canvas.setOriginalImage(origin: image)
            canvas.setMaskImage(mask: nil)
        }
        
        var button = UIButton(type: .system)
        button.setTitle("render", for: .normal)
        button.frame = .init(x: 0, y: kScreenHeight - 128, width: kScreenWidth / 2, height: 128)
        view.addSubview(button)
        button.addTarget(self, action: #selector(self.onButtonTap(_:)), for: .touchUpInside)
        
        button = UIButton(type: .system)
        button.setTitle("refresh", for: .normal)
        button.frame = .init(x: kScreenWidth / 2, y: kScreenHeight - 128, width: kScreenWidth / 2, height: 128)
        view.addSubview(button)
//        button.addTarget(self, action: #selector(self.onButtonTap2(_:)), for: .touchUpInside)
    }
    
    @objc func onButtonTap(_ sender: UIButton) {
        canvas.render_path_to_mask_texture()
        canvas.drawPaths.removeAll()
    }
    @objc func onButtonTap2(_ sender: UIButton) {
        canvas.draw(in: canvas.mtkView)
    }
}
