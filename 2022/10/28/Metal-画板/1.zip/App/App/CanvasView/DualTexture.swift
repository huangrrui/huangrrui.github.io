//
//  DualTexture.swift
//  App
//
//  Created by 黄瑞 on 2022/10/24.
//

import UIKit

class DualTexture: NSObject {
    /// 随着顶点数的增加，绘制时间也会延长，顶点到达一定数量后，将其转为 texture 保存下来
    private var index = 0
    var renderTargetTexture: MTLTexture! {
        get {
            return index == 0 ? texture1 : texture2
        }
    }
    var shaderReadTexture: MTLTexture! {
        get {
            return index == 1 ? texture1 : texture2
        }
    }
    
    // 双缓冲
    private let texture1: MTLTexture
    private let texture2: MTLTexture
    
    // 切换并返回 texture
    func swap() {
        index = index == 0 ? 1 : 0
    }
    
    init(descriptor: MTLTextureDescriptor, device: MTLDevice) {
        self.texture1 = device.makeTexture(descriptor: descriptor)!
        self.texture2 = device.makeTexture(descriptor: descriptor)!
        
        let width = descriptor.width
        let height = descriptor.height
        let region = MTLRegionMake2D(0, 0, width, height)
        let bytes: [UInt8] = Array(repeating: 0, count: width * height * 4)
        texture1.replace(region: region, mipmapLevel: 0, withBytes: bytes, bytesPerRow: width * 2)
        texture2.replace(region: region, mipmapLevel: 0, withBytes: bytes, bytesPerRow: width * 2)
    }
    
    func replace(region: MTLRegion, mipmapLevel level: Int, withBytes pixelBytes: UnsafeRawPointer, bytesPerRow: Int) {
        shaderReadTexture.replace(region: region, mipmapLevel: level, withBytes: pixelBytes, bytesPerRow: bytesPerRow)
    }
}
