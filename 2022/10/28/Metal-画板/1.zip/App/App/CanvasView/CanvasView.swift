//
//  CanvasView.swift
//  App
//
//  Created by 黄瑞 on 2022/10/17.
//

import UIKit
import MetalKit
import simd

struct CanvasVertex {
    var position: vector_float2
    var coord: vector_float2
}

struct PathVertex {
    var position: vector_float2
}

// 抠图控件，用来显示原图、与 mask 图合成后的控图结果等
// 显示方式为 fill
class CanvasView: UIView {
    var mtkView: MTKView!
    let device: MTLDevice
    let commandQueue: MTLCommandQueue

    private var render_image_pipeline: MTLRenderPipelineState? // 用于绘制底图与mask图
    private var render_paint_path_pipeline: MTLRenderPipelineState? // 用于绘制笔迹
    private var offscreen_render_mask_pipeline: MTLRenderPipelineState? // 用于mask图离屏渲染
    private var offscreen_render_path_pipeline: MTLRenderPipelineState? // 用于笔迹图离屏渲染
    
    // 原图
    private var originalImage: UIImage?
    private var originTexture: MTLTexture?
    
    // 遮罩，依据透明度来显示对应部分的原图内容
    private var maskImage: UIImage?
    private var maskTexture: DualTexture!
    private var maskRenderPass: MTLRenderPassDescriptor!

    // 绘制（标准设备坐标）
    var drawPaths: [PathVertex] = []
    private var brush: MTLTexture!

    // 变换
    private var image_transform: CATransform3D = CATransform3DIdentity
    private var scale: CGFloat = 1.0 // 缩放
    private var offset = CGPoint.zero // 位移
    private var rotation: CGFloat = 0 * CGFloat.pi // 旋转（弧度）
    private var brush_size: Float = 32 // 设定的笔刷大小
    /// 实际笔刷大小，基于原图尺寸，渲染时由于 viewport 不一定与原图尺寸一致，所以还需要根据 viewport 的大小进行缩放
    private var actual_brush_size: Float {
        get {
            guard let size = originalImage?.size,
                  let texture_height = originTexture?.height,
                  let texture_width = originTexture?.width else {
                return brush_size
            }
            
            let ratio = size.width / size.height
            if ratio > 1 {
                return brush_size / viewportSize.y * Float(ratio) * Float(texture_height) / Float(scale)
            } else {
                return brush_size / viewportSize.x / Float(ratio) * Float(texture_width) / Float(scale)
            }
        }
    }
    
    private var viewportSize = vector_float2.zero
    
    init(frame: CGRect, device: MTLDevice) {
        self.device = device
        self.commandQueue = device.makeCommandQueue()!

        super.init(frame: frame)
        
        mtkView = MTKView(frame: .init(origin: .zero, size: frame.size), device: device)
        mtkView.enableSetNeedsDisplay = false
        mtkView.clearColor = MTLClearColorMake(1, 1, 1, 1)
        addSubview(mtkView)

        init_pipeline()
        init_brush()
        
        mtkView.delegate = self

        mtkView(mtkView, drawableSizeWillChange: mtkView.drawableSize)
        
        let pan = UIPanGestureRecognizer(target: self, action: #selector(self.onPan(_:)))
        pan.delegate = self
        self.addGestureRecognizer(pan)
        
        let two_finger_pan = UIPanGestureRecognizer(target: self, action: #selector(self.on_two_finger_pan(_:)))
        two_finger_pan.minimumNumberOfTouches = 2
        two_finger_pan.delegate = self
        self.addGestureRecognizer(two_finger_pan)
        
        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(self.onPinch(_:)))
        pinch.delegate = self
        self.addGestureRecognizer(pinch)
        
        let rotate = UIRotationGestureRecognizer(target: self, action: #selector(self.onRotate(_:)))
        rotate.delegate = self
        self.addGestureRecognizer(rotate)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setOriginalImage(origin: UIImage) {
        self.originalImage = origin
        
        let cgImage = origin.cgImage!
        let imageData = cgImage.dataProvider!.data! as NSData
        
        let descriptor = MTLTextureDescriptor()
        descriptor.width = cgImage.width
        descriptor.height = cgImage.height
        descriptor.pixelFormat = .rgba8Unorm
        descriptor.textureType = .type2D
        descriptor.usage = [.shaderRead]
        originTexture = device.makeTexture(descriptor: descriptor)
        
        let region = MTLRegionMake2D(0, 0, cgImage.width, cgImage.height)
        originTexture?.replace(region: region, mipmapLevel: 0, withBytes: imageData.bytes, bytesPerRow: cgImage.bytesPerRow)
        
        image_transform = CATransform3DIdentity
        let ratio = origin.size.width / origin.size.height
        if ratio > 1 {
            image_transform = CATransform3DScale(image_transform, 1.0, 1.0 / ratio, 1.0)
        } else {
            image_transform = CATransform3DScale(image_transform, ratio, 1.0, 1.0)
        }
    }
    
    func setMaskImage(mask: UIImage?) {
        if mask == nil && originTexture != nil {
            let descriptor = MTLTextureDescriptor()
            descriptor.width = originTexture!.width
            descriptor.height = originTexture!.height
            descriptor.pixelFormat = .r16Unorm
            descriptor.textureType = .type2D
            descriptor.usage = [.shaderRead, .renderTarget]
            maskTexture = DualTexture(descriptor: descriptor, device: device)
            
            init_paint_render_pass()
        } else {
            self.maskImage = mask
            
            let cgImage = mask!.cgImage!
            let imageData = cgImage.dataProvider!.data! as NSData
            
            let descriptor = MTLTextureDescriptor()
            descriptor.width = cgImage.width
            descriptor.height = cgImage.height
            descriptor.pixelFormat = .r16Unorm
            descriptor.textureType = .type2D
            descriptor.usage = [.shaderRead, .renderTarget]
            maskTexture = DualTexture(descriptor: descriptor, device: device)
            
            let region = MTLRegionMake2D(0, 0, cgImage.width, cgImage.height)
            maskTexture.replace(region: region, mipmapLevel: 0, withBytes: imageData.bytes, bytesPerRow: cgImage.bytesPerRow)
            
            init_paint_render_pass()
        }
    }
    
    private func init_brush() {
        guard let path = Bundle.main.path(forResource: "brush", ofType: "png") else { return }
        guard let data = try? Data(contentsOf: URL(fileURLWithPath: path)) else { return }
        guard let image = UIImage(data: data) else { return }
        guard let cgImage = image.cgImage else { return }
        guard let imageData = cgImage.dataProvider?.data as? NSData else { return }

        let width = cgImage.width
        let height = cgImage.height

        let descriptor = MTLTextureDescriptor()
        descriptor.textureType = .type2D
        descriptor.width = width
        descriptor.height = height
        descriptor.pixelFormat = .rgba8Unorm
        descriptor.usage = [.shaderRead]
        brush = device.makeTexture(descriptor: descriptor)!

        brush.replace(region: MTLRegionMake2D(0, 0, width, width), mipmapLevel: 0, slice: 0, withBytes: imageData.bytes, bytesPerRow: cgImage.bytesPerRow, bytesPerImage: cgImage.bytesPerRow * height)
    }
    
    private func init_pipeline() {
        let library = device.makeDefaultLibrary()!
        var descriptor: MTLRenderPipelineDescriptor
        
        descriptor = MTLRenderPipelineDescriptor()
        descriptor.vertexFunction = library.makeFunction(name: "vertexShader")!
        descriptor.fragmentFunction = library.makeFunction(name: "fragmentShader")!
        descriptor.colorAttachments[0].pixelFormat = mtkView.colorPixelFormat
        render_image_pipeline = try! device.makeRenderPipelineState(descriptor: descriptor)
        
        descriptor = MTLRenderPipelineDescriptor()
        descriptor.vertexFunction = library.makeFunction(name: "vertexPaintShader")!
        descriptor.fragmentFunction = library.makeFunction(name: "fragmentPaintShader")!
        descriptor.colorAttachments[0].pixelFormat = mtkView.colorPixelFormat
        descriptor.isAlphaToCoverageEnabled = true
        render_paint_path_pipeline = try! device.makeRenderPipelineState(descriptor: descriptor)
        
        descriptor = MTLRenderPipelineDescriptor()
        descriptor.vertexFunction = library.makeFunction(name: "maskVertexShader")!
        descriptor.fragmentFunction = library.makeFunction(name: "maskFragmentShader")!
        descriptor.colorAttachments[0].pixelFormat = .r16Unorm
        offscreen_render_mask_pipeline = try! device.makeRenderPipelineState(descriptor: descriptor)
        
        descriptor = MTLRenderPipelineDescriptor()
        descriptor.vertexFunction = library.makeFunction(name: "maskPaintVertexShader")!
        descriptor.fragmentFunction = library.makeFunction(name: "maskPaintFragmentShader")!
        descriptor.colorAttachments[0].pixelFormat = .r16Unorm
        descriptor.isAlphaToCoverageEnabled = true
        offscreen_render_path_pipeline = try! device.makeRenderPipelineState(descriptor: descriptor)
    }

    // 用于将绘制轨迹存储为 texture
    private func init_paint_render_pass() {
        maskRenderPass = MTLRenderPassDescriptor()
        maskRenderPass.colorAttachments[0].texture = maskTexture.renderTargetTexture
        maskRenderPass.colorAttachments[0].loadAction = .clear
        maskRenderPass.colorAttachments[0].clearColor = MTLClearColorMake(0, 0, 0, 1)
        maskRenderPass.colorAttachments[0].storeAction = .store
    }
}

// MARK: - MTKViewDelegate
extension CanvasView: MTKViewDelegate {
    func draw(in view: MTKView) {
        let commandBuffer = commandQueue.makeCommandBuffer()!
        let commandEncoder = commandBuffer.makeRenderCommandEncoder(descriptor: view.currentRenderPassDescriptor!)!
        
        if let texturePipeline = self.render_image_pipeline {
            draw_texture(commandEncoder, texturePipeline)
        }
        if let paintPipeline = self.render_paint_path_pipeline, drawPaths.count >= 2 {
            draw_path(commandEncoder, paintPipeline)
        }
        
        commandEncoder.endEncoding()
        commandBuffer.present(view.currentDrawable!)
        commandBuffer.commit()
    }
    
    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
        print(size)
        viewportSize.x = Float(size.width)
        viewportSize.y = Float(size.height)
    }
    
    func render_path_to_mask_texture() {
        let commandBuffer = commandQueue.makeCommandBuffer()!
        
        let commandEncoder = commandBuffer.makeRenderCommandEncoder(descriptor: maskRenderPass)!
        offscreen_draw_mask(commandEncoder)
        if drawPaths.count >= 2 {
            offscreen_draw_path(commandEncoder)
        }
        commandEncoder.endEncoding()
        
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()
        maskTexture.swap()
        maskRenderPass.colorAttachments[0].texture = maskTexture.renderTargetTexture
    }

    /// 绘制底图与遮罩图合成后的图片
    func draw_texture(_ encoder: MTLRenderCommandEncoder, _ pipeline: MTLRenderPipelineState) {
        let vertices = [
            CanvasVertex(position: vector_float2(-1,  1), coord: vector_float2(0, 0)),
            CanvasVertex(position: vector_float2(-1, -1), coord: vector_float2(0, 1)),
            CanvasVertex(position: vector_float2( 1, -1), coord: vector_float2(1, 1)),
            
            CanvasVertex(position: vector_float2(-1,  1), coord: vector_float2(0, 0)),
            CanvasVertex(position: vector_float2( 1,  1), coord: vector_float2(1, 0)),
            CanvasVertex(position: vector_float2( 1, -1), coord: vector_float2(1, 1)),
        ]
        
        encoder.setRenderPipelineState(pipeline)
        
        encoder.setVertexBytes(vertices, length: MemoryLayout<CanvasVertex>.stride * vertices.count, index: 0)
        var transform = self.get_transform()
        encoder.setVertexBytes(&transform, length: MemoryLayout<simd_float4x4>.stride, index: 1)
        
        encoder.setFragmentTexture(originTexture, index: 0)
        encoder.setFragmentTexture(maskTexture.shaderReadTexture, index: 1)

        encoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: vertices.count)
    }
    
    /// 绘制笔迹
    func draw_path(_ encoder: MTLRenderCommandEncoder, _ pipeline: MTLRenderPipelineState) {
        encoder.setRenderPipelineState(pipeline)

        let buffer = device.makeBuffer(bytes: drawPaths, length: MemoryLayout<PathVertex>.stride * drawPaths.count)!
        encoder.setVertexBuffer(buffer, offset: 0, index: 0)
        // 计算笔刷大小
        encoder.setVertexBytes(&brush_size, length: MemoryLayout<Float>.stride, index: 1)
        encoder.setVertexBytes(&viewportSize, length: MemoryLayout<vector_float2>.stride, index: 2)

        encoder.setFragmentBytes(&viewportSize, length: MemoryLayout<vector_float2>.stride, index: 0)
        var transform = self.get_transform().inverse
        encoder.setFragmentBytes(&transform, length: MemoryLayout<simd_float4x4>.stride, index: 1)
        encoder.setFragmentTexture(brush, index: 0)
        encoder.setFragmentTexture(originTexture, index: 1)


        encoder.drawPrimitives(type: .point, vertexStart: 0, vertexCount: drawPaths.count)
    }
    
    /// 绘制遮罩图
    func offscreen_draw_mask(_ encoder: MTLRenderCommandEncoder) {
        let vertices = [
            CanvasVertex(position: vector_float2(-1,  1), coord: vector_float2(0, 0)),
            CanvasVertex(position: vector_float2(-1, -1), coord: vector_float2(0, 1)),
            CanvasVertex(position: vector_float2( 1, -1), coord: vector_float2(1, 1)),
            
            CanvasVertex(position: vector_float2(-1,  1), coord: vector_float2(0, 0)),
            CanvasVertex(position: vector_float2( 1,  1), coord: vector_float2(1, 0)),
            CanvasVertex(position: vector_float2( 1, -1), coord: vector_float2(1, 1)),
        ]
        
        encoder.setRenderPipelineState(offscreen_render_mask_pipeline!)

        encoder.setVertexBytes(vertices, length: MemoryLayout<CanvasVertex>.stride * vertices.count, index: 0)
        
        encoder.setFragmentTexture(maskTexture.shaderReadTexture, index: 0)

        encoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: vertices.count)
    }
    
    func offscreen_draw_path(_ encoder: MTLRenderCommandEncoder) {
        encoder.setRenderPipelineState(offscreen_render_path_pipeline!)

        let buffer = device.makeBuffer(bytes: drawPaths, length: MemoryLayout<PathVertex>.stride * drawPaths.count)!
        encoder.setVertexBuffer(buffer, offset: 0, index: 0)
        var draw_brush_size = self.actual_brush_size
        encoder.setVertexBytes(&draw_brush_size, length: MemoryLayout<Float>.stride, index: 1)
        encoder.setVertexBytes(&viewportSize, length: MemoryLayout<vector_float2>.stride, index: 2)
        var transform = self.get_transform().inverse
        encoder.setVertexBytes(&transform, length: MemoryLayout<simd_float4x4>.stride, index: 3)

        encoder.setFragmentTexture(brush, index: 0)

        encoder.drawPrimitives(type: .point, vertexStart: 0, vertexCount: drawPaths.count)
    }
}

// MARK: - Gesture
extension CanvasView {
    @objc func onPan(_ sender: UIPanGestureRecognizer) {
        var point = sender.location(in: sender.view)
        point = .init(x: point.x - frame.width / 2, y: frame.height / 2 - point.y)
        point = .init(x: point.x / frame.width * CGFloat(viewportSize.x), y: point.y / frame.size.height * CGFloat(viewportSize.y))
        let vector_point = vector_float2(x: Float(point.x), y: Float(point.y))
        
        switch sender.state {
        case .began:
            if !drawPaths.isEmpty {
                if drawPaths.last!.position != vector_point {
                    drawPaths.append(PathVertex(position: vector_point))
                }
            } else {
                drawPaths.append(PathVertex(position: vector_point))
            }
        case .changed:
            bresenham(v0: drawPaths.last!, v1: PathVertex(position: vector_point))
            if drawPaths.count > 2000 {
                render_path_to_mask_texture()
                let path = drawPaths.last!
                drawPaths.removeAll()
                drawPaths.append(path)
            }
        case .ended:
            render_path_to_mask_texture()
            drawPaths.removeAll()
        default: break
        }
    }
    
    @objc func on_two_finger_pan(_ sender: UIPanGestureRecognizer) {
        switch sender.state {
        case .changed:
            let translate = sender.translation(in: sender.view)
            
            let translate_x: Double
            let translate_y: Double
            
            if let size = originalImage?.size {
                let ratio = size.width / size.height
                if ratio > 1 {
                    translate_x = translate.x * cos(rotation) - translate.y * sin(rotation)
                    translate_y = translate.x * ratio * sin(rotation) + translate.y * ratio * cos(rotation)
                } else {
                    translate_x = translate.x / ratio * cos(rotation) - translate.y / ratio * sin(rotation)
                    translate_y = translate.x * sin(rotation) + translate.y * cos(rotation)
                }
            } else {
                translate_x = translate.x
                translate_y = translate.y
            }
            
            offset.x = offset.x + translate_x / frame.width * 2 / scale
            offset.y = offset.y - translate_y / frame.height * 2 / scale
            
            sender.setTranslation(.zero, in: sender.view)
        default: break
        }

    }
    
    @objc func onPinch(_ sender: UIPinchGestureRecognizer) {
        switch sender.state {
        case .changed:
            scale = scale * sender.scale
            sender.scale = 1.0
        default: break
        }
    }
    
    @objc func onRotate(_ sender: UIRotationGestureRecognizer) {
        switch sender.state {
        case .changed:
            rotation = rotation - sender.rotation
            sender.rotation = 0
        default: break
        }
    }
}

// MARK: - Algorithmn
extension CanvasView {
    /// bresenham 点插值算法
    func bresenham(v0: PathVertex, v1: PathVertex) -> Void {
        var x0 = Int(v0.position.x)
        var y0 = Int(v0.position.y)
        let x1 = Int(v1.position.x)
        let y1 = Int(v1.position.y)
        
        let dx = abs(x1 - x0)
        let sx = x0 < x1 ? 1 : -1
        let dy = abs(y1 - y0)
        let sy = y0 < y1 ? 1 : -1
        var err = (dx > dy ? dx : -dy) / 2

        while x0 != x1 || y0 != y1 {
            let vector_point = vector_float2(Float(x0), Float(y0))
            if !drawPaths.isEmpty {
                if drawPaths.last!.position != vector_point {
                    drawPaths.append(PathVertex(position: vector_point))
                }
            } else {
                drawPaths.append(PathVertex(position: vector_point))
            }

            let e2 = err
            if e2 > -dx {
                err -= dy
                x0 += sx
            }
            if e2 <  dy {
                err += dx
                y0 += sy
            }
        }
    }
    
    func get_transform() -> simd_float4x4 {
        var transform = CATransform3DIdentity
//        transform = CATransform3DConcat(CATransform3DMakeTranslation(offset.x, offset.y, 0), transform)
//        transform = CATransform3DConcat(CATransform3DMakeRotation(rotation, 0, 0, 1), transform)
//        transform = CATransform3DConcat(image_transform, transform)
//        transform = CATransform3DConcat(CATransform3DMakeScale(scale, scale, 1), transform)
        
        transform = CATransform3DConcat(CATransform3DMakeRotation(rotation, 0, 0, 1), transform)
        transform = CATransform3DConcat(image_transform, transform)
        transform = CATransform3DConcat(CATransform3DMakeScale(scale, scale, 1), transform)
        transform = CATransform3DConcat(CATransform3DMakeTranslation(offset.x, offset.y, 0), transform)
        
        return simd_float4x4(rows: [
            vector_float4(Float(transform.m11), Float(transform.m12), Float(transform.m13), Float(transform.m14)),
            vector_float4(Float(transform.m21), Float(transform.m22), Float(transform.m23), Float(transform.m24)),
            vector_float4(Float(transform.m31), Float(transform.m32), Float(transform.m33), Float(transform.m34)),
            vector_float4(Float(transform.m41), Float(transform.m42), Float(transform.m43), Float(transform.m44)),
        ])
    }
            
    /// 构建 lookAt 矩阵
    func m_lookat(pos: vector_float3, target: vector_float3, up: vector_float3) -> matrix_float4x4 {
        let forward = simd_normalize(target - pos)
        let right = simd_normalize(simd_cross(up, forward))
        let new_up = simd_normalize(simd_cross(forward, right))
        var lookat = matrix_float4x4()
        lookat.columns.0 = vector_float4(right, 0)
        lookat.columns.1 = vector_float4(new_up, 0)
        lookat.columns.2 = vector_float4(forward, 0)
        lookat.columns.3 = vector_float4(pos, 1)
        return lookat
    }
}

// MARK: - UIGestureRecognizerDelegate
extension CanvasView: UIGestureRecognizerDelegate {
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        if gestureRecognizer is UIPanGestureRecognizer && (gestureRecognizer as! UIPanGestureRecognizer).minimumNumberOfTouches == 1 {
            return false
        } else if otherGestureRecognizer is UIPanGestureRecognizer && (otherGestureRecognizer as! UIPanGestureRecognizer).minimumNumberOfTouches == 1 {
            return false
        } else {
            return true
        }
    }
}

// MARK: - Test
extension CanvasView {
}
